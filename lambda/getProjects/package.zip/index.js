const BuckConstants = require('./buck-constants');

// Import the MongoDB driver
const MongoClient = require("mongodb").MongoClient;

// Define our connection string. Info on where to get this will be described below. In a real world application you'd want to get this string from a key vault like AWS Key Management, but for brevity, we'll hardcode it in our serverless function here.
const MONGODB_URI =
    "mongodb://bucktraceuser:Password1*@bucktrace-shard-00-00.u4wwf.mongodb.net:27017,bucktrace-shard-00-01.u4wwf.mongodb.net:27017,bucktrace-shard-00-02.u4wwf.mongodb.net:27017/bucktrace?ssl=true&replicaSet=atlas-969ypb-shard-0&authSource=admin&retryWrites=true&w=majority";

// Once we connect to the database once, we'll store that connection and reuse it so that we don't have to connect to the database on every request.
let cachedDb = null;

async function connectToDatabase() {
    if (cachedDb) {
        return cachedDb;
    }

    // Connect to our MongoDB database hosted on MongoDB Atlas
    const client = await MongoClient.connect(MONGODB_URI);

    // Specify which database we want to use
    const db = await client.db("bucktrace");

    cachedDb = db;
    return db;
}

exports.handler = async (event, context) => {

    /* By default, the callback waits until the runtime event loop is empty before freezing the process and returning the results to the caller. Setting this property to false requests that AWS Lambda freeze the process soon after the callback is invoked, even if there are events in the event loop. AWS Lambda will freeze the process, any state data, and the events in the event loop. Any remaining events in the event loop are processed when the Lambda function is next invoked, if AWS Lambda chooses to use the frozen process. */
    //context.callbackWaitsForEmptyEventLoop = false;

    // // Get an instance of our database
    // const db = await connectToDatabase();
    // const query = { _id: event.queryStringParameters.sn }
    // console.log("Constants", BuckConstants);

    // //    const movies = await db.collection("Bucks").find({}).limit(20).toArray();
    // const movies = await db.collection("Bucks").find(query).toArray();

    // {
    //     "sn": "string",
    //     "address": "string",
    //     "city": "string",
    //     "state": "string",
    //     "zip": "string",
    //     "lat": 0,
    //     "long": 0
    //   }

    // const serialNumber = 'I01234567Y';

    console.log("event.body", event.body);


    const serialNumber = event.body.sn;
    const sn = serialNumber.toLocaleUpperCase();
    const sd = sn.substring(1, 9);
    const frl = sn.substring(0, 1);
    const frd = sn.charCodeAt(0) - 65 + 1;
    const dn = 1;
    const px = frl;
    const sx = sn.substring(9);
    const fw = false;

    const bank = BuckConstants.banks.find(bank => bank.district === frd);
    const uId = 27;
    const bep = 0; //0=dc, 1=fw

    const newBuck = {
        "_id": sn,
        "SD": sd,
        "FRD": frd,
        "DN": dn,
        "FRL": frl,
        "PX": px,
        "SX": sx,
        "FW": fw,
        "HIST": [
            {
                "_t": "Bank",
                "Lat": bank.lat,
                "Long": bank.long,
                "UserId": uId,
                "City": bank.city,
                "State": bank.state,
                "Zip": bank.zip,
                "FullAddress": `${bank.address1} ${bank.address2} ${bank.city}, ${bank.state} ${bank.zip}`,
                "Name": bank.name,
                "TraceDate": new Date("1993-07-27T00:00:00.000Z"),
                "Photo": null,
                "Address1": bank.address1,
                "FromAPI": false,
                "Address2": bank.address2
            },
            {
                "Lat": 32.7668015113796,
                "Long": -97.0808079632892,
                "UserId": uId,
                "City": "Arlington",
                "State": "TX",
                "Zip": "76006",
                "FullAddress": null,
                "Name": null,
                "TraceDate": new Date("2022-05-13T13:19:49.205Z"),
                "Photo": null,
                "Address1": "Wood Creek, US",
                "FromAPI": false
            }
        ],
        "SRS": null,
        "BEP": bep,
        "CDT": new Date(),
        "UDT": new Date(),
        "MAT": {
            "IsAllPairs2": false,
            "IsAllPairs4": false,
            "IsRepeatingPairs2": false,
            "IsRepeatingPairs4": false,
            "IsConsectutiveAscending": false,
            "IsConsectutiveDescending": false,
            "IsConsectutivePairAscending": false,
            "IsConsectutivePairDescending": false,
            "IsUniqueDigits": false,
            "IsOneDigit": false,
            "IsTwoDigits": false,
            "IsSixOrMoreSameDigit": false,
            "IsPalindrome": false,
            "IsDate": false
        },
        "DBMAT": false,
        "Errors": null,
        "B64_CAP": null,
        "DSRSCT": frd,
        "DSTCITY": bank.city,
        "CA": false
    }

    const response = {
        statusCode: 200,
        body: JSON.stringify(newBuck),
        event: JSON.stringify(event)
    };

    return response;
};

